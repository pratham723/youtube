# youtube-clone
YouTube clone with HTML and CSS

### Description
* Built this project to test my knowledge on embedding images and videos in a webpage. 
* Also wanted to see how well my understanding of CSS grid layouts is
* Also applied some BEM in the styling to apply my learning knowledge of that too.

### Live site
* [YouTube Clone](https://dancarl857.github.io/youtube-clone/)